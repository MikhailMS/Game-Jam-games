package com.northernlights.possessme.desktop;

import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
import com.badlogic.gdx.backends.lwjgl.LwjglApplicationConfiguration;
import com.northernlights.possessme.GameStage;
import com.northernlights.possessme.PossessMe;

public class DesktopLauncher {
	public static void main (String[] arg) {
		LwjglApplicationConfiguration config = new LwjglApplicationConfiguration();

		config.width = 1000;
		config.height = 600;
		
		new LwjglApplication(new PossessMe(), config);
	}
}
