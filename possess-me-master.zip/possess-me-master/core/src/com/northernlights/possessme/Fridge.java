package com.northernlights.possessme;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Fridge {
	private Sprite sprite;

	public Fridge()
	{
		sprite = new Sprite(new Texture("fridge.png"));
		sprite.setPosition(23*32, 22*32);
	}
	
	public void draw(SpriteBatch batch)
	{
		sprite.draw(batch);
	}

	public void handle(int screenX, int screenY) {
		// TODO Auto-generated method stub
		
	}
}
