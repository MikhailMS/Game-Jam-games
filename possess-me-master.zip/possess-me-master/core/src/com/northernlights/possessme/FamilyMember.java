package com.northernlights.possessme;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public interface FamilyMember {
	
	public void update(float deltaTime);
	public void draw(SpriteBatch batch);

}
