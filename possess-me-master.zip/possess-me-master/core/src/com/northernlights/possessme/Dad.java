package com.northernlights.possessme;

import java.util.ArrayList;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector2;

public class Dad implements FamilyMember {
	
	PossessMe game;
	//private Sprite sprite;
	public int posX;
	public int posY;
	
	public int toX;
	public int toY;
	
	public float speed = 32f; //pixels per ms
	
	float timer = 0;
	private Animation animation;
	private float stateTime;

	public Dad(PossessMe game)
	{
		Texture spriteSheet = new Texture("dad.png");
		TextureRegion[][] tmp = TextureRegion.split(spriteSheet, spriteSheet.getWidth()/3, spriteSheet.getHeight());
		TextureRegion[] frames = new TextureRegion[4];
		
		frames[0] = tmp[0][0];
		frames[1] = tmp[0][1];
		frames[2] = tmp[0][0];
		frames[3] = tmp[0][2];
		
		animation = new Animation(0.2f, frames);
		//frames.dispose();
		
		
		this.game = game;
		//sprite = new Sprite(new Texture("dad.png"));
		moveToSquare(2,2);
	}
	
	@Override
	public void update(float deltaTime) {
		timer += deltaTime;
		stateTime += deltaTime;
		if(timer > 1)
		{
			timer -= 1;
			
			ArrayList<Node> avail = getPossibleMoves();
			
			int randomIndex = (int) (Math.random() * avail.size());
			
			//System.out.println(avail.size());
			
			
			if(!avail.isEmpty())
			{
				Node move = avail.get(randomIndex);
				
				moveToSquare(move.x, move.y);
			}
		}
	}

	@Override
	public void draw(SpriteBatch batch) {
		//sprite.draw(batch);
		System.out.println(stateTime);
		batch.draw(animation.getKeyFrame(stateTime, true), posX*32, posY*32);
		
	}
	
	public void moveToSquare(int x, int y)
	{
		posX = x;
		posY = y;
		//int w = (int) game.camera.viewportWidth;
		//int h = (int) game.camera.viewportHeight;
		
		//sprite.setPosition(w/2+x*8, h/2+y*8);
		
		//sprite.setPosition(x*32, y*32);
	}
	
	public ArrayList<Node> getPossibleMoves()
	{
		ArrayList<Node> returnList = new ArrayList<Node>();
		
		int x = posX;
		int y = /*game.mapHeight -*/ posY;
		
		for(Vector2 v : game.fourDirections)
		{
			int newX = (int) (x + v.x);
			int newY = (int) (y + v.y);
			
			if(newX >= 0 && newX < game.mapWidth && newY >= 0 && newY < game.mapHeight)
				if(game.wallMap1[newX][newY])
					returnList.add(new Node(newX, /*game.mapHeight -*/ newY));
		}
		
		return returnList;
	}

}
