package com.northernlights.possessme;

public class Node {
	
	public Node parent;
	
	public int x;
	public int y;
	
	public Node(int x, int y)
	{
		this.x = x;
		this.y = y;
	}

}
