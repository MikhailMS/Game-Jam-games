package com.northernlights.possessme;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Television {
	
	private Sprite sprite;

	public Television()
	{
		sprite = new Sprite(new Texture("television.png"));
		sprite.setPosition(10*32, 23*32);
	}
	
	public void draw(SpriteBatch batch)
	{
		sprite.draw(batch);
	}

	public void handle(int screenX, int screenY) {
		// TODO Auto-generated method stub
		
	}

}
