package com.northernlights.possessme;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Toilet {
	
	private Sprite toilet;

	public Toilet()
	{
        toilet = new Sprite(new Texture("toilet.png"));
        toilet.setPosition(1*32, 20*32);
	}

	
	public void draw(SpriteBatch batch)
	{
		toilet.draw(batch);
	}


	public void handle(int screenX, int screenY) {
		// TODO Auto-generated method stub
		
	}
}
