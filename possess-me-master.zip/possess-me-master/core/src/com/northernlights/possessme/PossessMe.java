package com.northernlights.possessme;

import java.util.ArrayList;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.maps.MapLayer;
import com.badlogic.gdx.maps.MapProperties;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.viewport.FitViewport;

public class PossessMe extends ApplicationAdapter implements InputProcessor {
	
	SpriteBatch batch;
	//Image texture;
	public OrthographicCamera camera;
	private TiledMap tiledMap;
	private OrthogonalTiledMapRenderer tiledMapRenderer;
	private static final int WIDTH = 1000;
	private static final int HEIGHT = 600;
	
	
	boolean scrollLeft;
	boolean scrollRight;
	boolean scrollUp;
	boolean scrollDown;
	int scrollIncrement = 10;
	public Integer mapWidth;
	public Integer mapHeight;
	
	ArrayList<FamilyMember> family = new ArrayList<FamilyMember>();
	public FitViewport viewport;
	public boolean[][] wallMap1;
	public boolean[][] wallMap2;
	
	public final Vector2[] fourDirections = {
		new Vector2(-1,0), new Vector2(0, -1),
		new Vector2(1,0), new Vector2(0, 1)
	};
	private Sprite sprite;
	private Toilet toilet;
	private Television television;
	private Toaster toaster;
	private Fridge fridge;
	
	private Music menuMusic;
	
	public int floor = 1;
	
	@Override
	public void create () {
		batch = new SpriteBatch();
		
		float w = Gdx.graphics.getWidth();
        float h = Gdx.graphics.getHeight();

        camera = new OrthographicCamera();
        camera.setToOrtho(false, w, h);
        camera.update();
        
        tiledMap = new TmxMapLoader().load("house.tmx");
        tiledMapRenderer = new OrthogonalTiledMapRenderer(tiledMap);
        Gdx.input.setInputProcessor(this);
        
        viewport = new FitViewport(WIDTH, HEIGHT, camera);
        
        MapProperties prop = tiledMap.getProperties();

        mapWidth = prop.get("width", Integer.class);
        mapHeight = prop.get("height", Integer.class);
        
        family.add(new Dad(this));
        family.add(new Mom(this));
        sprite = new Sprite(new Texture("car.png"));
        sprite.setPosition(2*32, 5*32);
        
        
        toilet = new Toilet();
        television = new Television();
        toaster = new Toaster();
        fridge = new Fridge();
        
        
        //System.out.println(Gdx.graphics.getWidth()/2 + mapWidth);
        TiledMapTileLayer ml = (TiledMapTileLayer) tiledMap.getLayers().get(5);
        
        wallMap1 = new boolean[ml.getWidth()][ml.getHeight()];
        
        for(int x = 0; x < ml.getWidth(); x++)
        	for(int y = 0; y < ml.getHeight(); y++)
        	{
        		String passable = ml.getCell(x, y).getTile().getProperties().get("passable").toString();
        		
        		//if(!passable.equals("true") && !passable.equals("false"))
        			//System.out.println(passable);
        		
        		if(passable.equals("true"))
        			wallMap1[x][y] = true;
        		else
        			wallMap1[x][y] = false;
        	}
        		
        
        TiledMapTileLayer ml2 = (TiledMapTileLayer) tiledMap.getLayers().get(6);
        
        wallMap2 = new boolean[ml2.getWidth()][ml2.getHeight()];
        
        for(int x = 0; x < ml2.getWidth(); x++)
        	for(int y = 0; y < ml2.getHeight(); y++)
        	{
        		int id = ml.getCell(x, 1).getTile().getId();
        		if(id == 258)
        			wallMap2[x][y] = true;
        		else
        			wallMap2[x][y] = false;
        		//257 - impassable
        		//258 - passable
        	}
        
        //System.out.println(ml.getWidth()+" "+ml.getHeight());
        //MapLayer ml2 = tiledMap.getLayers().get(6);
        //System.out.println(ml.getWidth());
        
        // Music goes here
        menuMusic = Gdx.audio.newMusic(Gdx.files.external("/Desktop/My Projects/Game_Jam/core/assets/sounds/game.wav"));
        menuMusic.setLooping(true);
        menuMusic.play();
	}

	@Override
	public void render () {
		Gdx.gl.glClearColor(0.18f, 0.18f, 0.70f, 0.06f);
		Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		camera.update();
		tiledMapRenderer.setView(camera);
		tiledMap.getLayers().get(5).setVisible(false);
		tiledMap.getLayers().get(6).setVisible(false);
		tiledMapRenderer.render();
	        
	     // -------------------
	     // These values likely need to be scaled according to your world coordinates.
	     // The left boundary of the map (x)
	     int mapLeft = 0;
	     // The right boundary of the map (x + width)
	     int mapRight = 0 + WIDTH;
	     // The bottom boundary of the map (y)
	     int mapBottom = 0;
	     // The top boundary of the map (y + height)
	     int mapTop = 0 + HEIGHT;
	     // The camera dimensions, halved
	     float cameraHalfWidth = camera.viewportWidth * .5f;
	     float cameraHalfHeight = camera.viewportHeight * .5f;

	     // Move camera after player as normal

	     float cameraLeft = camera.position.x - cameraHalfWidth;
	     float cameraRight = camera.position.x + cameraHalfWidth;
	     float cameraBottom = camera.position.y - cameraHalfHeight;
	     float cameraTop = camera.position.y + cameraHalfHeight;

	     // Horizontal axis
	     /*if(mapWidth < camera.viewportWidth) {
	         camera.position.x = mapRight / 2;
	     }
	     else if(cameraLeft <= mapLeft) {
	         camera.position.x = mapLeft + cameraHalfWidth;
	     }
	     else if(cameraRight >= mapRight) {
	         camera.position.x = mapRight - cameraHalfWidth;
	     }

	     // Vertical axis
	     if(mapHeight < camera.viewportHeight) {
	         camera.position.y = mapTop / 2;
	     }
	     else if(cameraBottom <= mapBottom) {
	         camera.position.y = mapBottom + cameraHalfHeight;
	     }
	     else if(cameraTop >= mapTop) {
	         camera.position.y = mapTop - cameraHalfHeight;
	     }*/
	        // -------------------
	        
        //System.out.println(camera.position.x);
        
        //camera.position.x = MathUtils.clamp(camera.position.x, camViewportHalfX, mapWidth - camViewportHalfX);
        //camera.position.y = MathUtils.clamp(camera.position.y, camViewportHalfY, mapHeight - camViewportHalfY)
        if(scrollLeft) {
        	if(camera.position.x - scrollIncrement < Gdx.graphics.getWidth()/2)
        		camera.position.x = camera.viewportWidth/2;
        	else
        		camera.translate(-scrollIncrement, 0);
        }
        if(scrollRight) {
        	if(camera.position.x + scrollIncrement > Gdx.graphics.getWidth()/2 + mapWidth)
        		camera.position.x = Gdx.graphics.getWidth()/2 + mapWidth;
        	else
        		camera.translate(scrollIncrement, 0);
        }
        if(scrollUp) {
        	if(camera.position.y + scrollIncrement > Gdx.graphics.getHeight())
        		camera.position.y = Gdx.graphics.getHeight();
        	else
        		camera.translate(0, scrollIncrement);
        }
        if(scrollDown) {
        	if(camera.position.y - scrollIncrement < Gdx.graphics.getHeight()/2)
        		camera.position.y = Gdx.graphics.getHeight()/2;
        	else
        		camera.translate(0, -scrollIncrement);
        }

        System.out.println(camera.position.x+ " "+camera.position.y);

        
        batch.setProjectionMatrix(camera.combined);
        batch.begin();
        
        if(floor == 1)
        {
	        
	        toilet.draw(batch);
	        sprite.draw(batch);
	        television.draw(batch);
	        toaster.draw(batch);
	        fridge.draw(batch);
        }
        
        for(FamilyMember f : family)
        {
        	f.update(Gdx.graphics.getDeltaTime());
        	f.draw(batch);
        }
        
        batch.end();
        
	}

	@Override
	public boolean keyDown(int keycode) {
		
		if(keycode == Input.Keys.W)
			scrollUp = true;
		if(keycode == Input.Keys.A)
			scrollLeft = true;
		if(keycode == Input.Keys.S)
			scrollDown = true;
		if(keycode == Input.Keys.D)
			scrollRight = true;
		
		if(keycode == Input.Keys.UP)
			scrollUp = true;
		if(keycode == Input.Keys.LEFT)
			scrollLeft = true;
		if(keycode == Input.Keys.DOWN)
			scrollDown = true;
		if(keycode == Input.Keys.RIGHT)
			scrollRight = true;
	        
		return true;
	}

	@Override
	public boolean keyUp(int keycode) {
		
		
		if(keycode == Input.Keys.W)
			scrollUp = false;
		if(keycode == Input.Keys.A)
			scrollLeft = false;
		if(keycode == Input.Keys.S)
			scrollDown = false;
		if(keycode == Input.Keys.D)
			scrollRight = false;
		
		if(keycode == Input.Keys.UP)
			scrollUp = false;
		if(keycode == Input.Keys.LEFT)
			scrollLeft = false;
		if(keycode == Input.Keys.DOWN)
			scrollDown = false;
		if(keycode == Input.Keys.RIGHT)
			scrollRight = false;


		return false;
	}

	@Override
	public boolean keyTyped(char character) {

        if(character == 'f' || character == 'F') {
        	tiledMap.getLayers().get(2).setVisible(!tiledMap.getLayers().get(2).isVisible());
        	tiledMap.getLayers().get(3).setVisible(!tiledMap.getLayers().get(3).isVisible());
        	
        	if(floor == 1)
        		floor = 2;
        	else
        		floor = 1;
        }
        return true;
	}

	@Override
	public boolean touchDown(int screenX, int screenY, int pointer, int button) {
		// TODO Auto-generated method stub
		
		System.out.println("Click at: "+screenX+", "+screenY+". Pointer: "+pointer);
		return false;
	}

	@Override
	public boolean touchUp(int screenX, int screenY, int pointer, int button) {
        toilet.handle(screenX, screenY);
        television.handle(screenX, screenY);
        toaster.handle(screenX, screenY);
        fridge.handle(screenX, screenY);
        
        System.out.println(screenX + " : " + screenY);
        
		return false;
	}

	@Override
	public boolean touchDragged(int screenX, int screenY, int pointer) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean mouseMoved(int screenX, int screenY) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean scrolled(int amount) {
		// TODO Auto-generated method stub
		return false;
	}
}
