package com.northernlights.possessme;

import java.util.ArrayList;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;

public class Mom implements FamilyMember {
	
	PossessMe game;
	private Sprite sprite;
	public int posX;
	public int posY;
	
	public int toX;
	public int toY;
	
	public float speed = 32f; //pixels per ms
	
	float timer = 0;

	public Mom(PossessMe game)
	{
		this.game = game;
		sprite = new Sprite(new Texture("mom.png"));
		moveToSquare(2,2);
	}
	
	@Override
	public void update(float deltaTime) {
		timer += deltaTime;
		
		if(timer > 0.2)
		{
			timer -= 0.2;
			
			ArrayList<Node> avail = getPossibleMoves();
			
			int randomIndex = (int) (Math.random() * avail.size());
			
			//System.out.println(avail.size());
			
			
			if(!avail.isEmpty())
			{
				Node move = avail.get(randomIndex);
				
				moveToSquare(move.x, move.y);
			}
		}
	}

	@Override
	public void draw(SpriteBatch batch) {
		sprite.draw(batch);
		
	}
	
	public void moveToSquare(int x, int y)
	{
		posX = x;
		posY = y;
		//int w = (int) game.camera.viewportWidth;
		//int h = (int) game.camera.viewportHeight;
		
		//sprite.setPosition(w/2+x*8, h/2+y*8);
		sprite.setPosition(x*32, y*32);
	}
	
	public ArrayList<Node> getPossibleMoves()
	{
		ArrayList<Node> returnList = new ArrayList<Node>();
		
		int x = posX;
		int y = /*game.mapHeight -*/ posY;
		
		for(Vector2 v : game.fourDirections)
		{
			int newX = (int) (x + v.x);
			int newY = (int) (y + v.y);
			
			if(newX >= 0 && newX < game.mapWidth && newY >= 0 && newY < game.mapHeight)
				if(game.wallMap1[newX][newY])
					returnList.add(new Node(newX, /*game.mapHeight -*/ newY));
		}
		
		return returnList;
	}

}
